//: A UIKit based Playground for presenting user interface
  
import UIKit

let uno = Float(5)
let dos = Float(4)

func suma(primerNumero: Float, segundoNumero: Float){
            let result = primerNumero + segundoNumero
            print("Suma: \(result)")
    }
    suma(primerNumero: uno, segundoNumero: dos)
    
func resta(primerNumero: Float, segundoNumero: Float){
            let result = primerNumero - segundoNumero
            print("Resta: \(result)")
    }
    resta(primerNumero: uno, segundoNumero: dos)
    
func multi(primerNumero: Float, segundoNumero: Float){
            let result = primerNumero * segundoNumero
            print("Multiplicacion: \(result)")
    }
    multi(primerNumero: uno, segundoNumero: dos)
    
func division(primerNumero: Float, segundoNumero: Float){
            let result = primerNumero / segundoNumero
            print("Division: \(result)")
    }
    division(primerNumero: uno, segundoNumero: dos)


